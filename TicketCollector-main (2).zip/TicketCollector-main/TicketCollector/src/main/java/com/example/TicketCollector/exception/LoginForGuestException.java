package com.example.TicketCollector.exception;

public class LoginForGuestException extends RuntimeException{
    public LoginForGuestException(String message) {
        super(message);
    }
}
