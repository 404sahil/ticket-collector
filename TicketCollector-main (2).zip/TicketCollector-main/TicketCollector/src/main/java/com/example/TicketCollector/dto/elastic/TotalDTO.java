package com.example.TicketCollector.dto.elastic;

import lombok.*;

@Getter
@Setter
@ToString
@AllArgsConstructor
@NoArgsConstructor
public class TotalDTO {

    private Long value;

    private String relation;

}