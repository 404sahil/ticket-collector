package com.example.TicketCollector.exception;

public class TravellingModeTimeExcetion  extends RuntimeException {
    public TravellingModeTimeExcetion(String message) {
        super(message);
    }
}

