package com.example.TicketCollector.exception;

public class TravellingModeNotFound extends RuntimeException {
    public TravellingModeNotFound(String message) {
        super(message);
    }
}
