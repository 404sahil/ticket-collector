package com.example.TicketCollector.exception;

public class SourceDestinetionNotFoundException extends RuntimeException
{
    public SourceDestinetionNotFoundException(String message) {
        super(message);
    }
}

